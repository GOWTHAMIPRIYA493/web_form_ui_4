import './App.css';
import ApiCall from './components/apiCall';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <div className="App">
      <ApiCall/>
    </div>
  );
}

export default App;
